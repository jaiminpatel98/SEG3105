/**
 * @author jaxbl
 */

package dateP;

import java.util.List;
import java.util.LinkedList;
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runners.Parameterized;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized.Parameters;
import org.junit.Assert;


import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Suite;


@RunWith( Parameterized.class)
public class ParameterizedDateTest {
	
	private Date testDate;
	
	private Date expectedDate;
	
	public ParameterizedDateTest (Date testDate, Date expected) {
		this.testDate = testDate;
		this.expectedDate = expected;
	}
	
	@Parameters
	public static List<Date[]> data() {
		List<Date[]> params = new LinkedList<Date[]>();
		params.add(new Date[] {new Date(1700, 06, 20).nextDate(), new Date(1700, 06, 21)});
		params.add(new Date[] {new Date(2005, 04, 15).nextDate(), new Date(2005, 04, 16)});
		params.add(new Date[] {new Date(1901, 07, 20).nextDate(), new Date(1901, 07, 21)});
		params.add(new Date[] {new Date(3456, 03, 27).nextDate(), new Date(3456, 03, 28)});
		params.add(new Date[] {new Date(1500, 02, 17).nextDate(), new Date(1500, 02, 18)});
		params.add(new Date[] {new Date(1700, 06, 29).nextDate(), new Date(1700, 06, 30)});
		params.add(new Date[] {new Date(1800, 11, 29).nextDate(), new Date(1800, 11, 30)});
		params.add(new Date[] {new Date(3453, 01, 29).nextDate(), new Date(3453, 01, 30)});
		params.add(new Date[] {new Date(444, 02, 29).nextDate(), new Date(444, 03, 01)});
		params.add(new Date[] {new Date(2005, 04, 30).nextDate(), new Date(2005, 05, 01)});
		params.add(new Date[] {new Date(3453, 01, 30).nextDate(), new Date(3453, 01, 31)});
		params.add(new Date[] {new Date(3456, 03, 30).nextDate(), new Date(3456, 03, 31)});
		params.add(new Date[] {new Date(1901, 07, 31).nextDate(), new Date(1901, 8, 01)});
		params.add(new Date[] {new Date(3453, 01, 31).nextDate(), new Date(3453, 02, 01)});
		params.add(new Date[] {new Date(3456, 12, 31).nextDate(), new Date(3457, 01, 01)});
		
		return params;
	}
	
	@Test
	public void testDate() {
		
	}
	
}
