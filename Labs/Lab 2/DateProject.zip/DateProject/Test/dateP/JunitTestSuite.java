/**
 * @author jaxbl
 */
package dateP;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
	ParameterizedDateTest.class,
	ParameterizedDateTestExceptions.class
})

public class JunitTestSuite {
	
}
