/**
 * @author jaxbl
 */

package dateP;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


public class DateNonParameterizedTest {
	
	@Test
	public void nextDateTestPass () {
		System.out.println("Test");
		
		Assert.assertEquals(new Date(1700, 06, 21), new Date(1700, 06, 20).nextDate());
		Assert.assertEquals(new Date(2005, 04, 16), new Date(2005, 04, 15).nextDate());
		Assert.assertEquals(new Date(1901, 07, 21), new Date(1901, 07, 20).nextDate());
		Assert.assertEquals(new Date(3456, 03, 28), new Date(3456, 03, 27).nextDate());
		Assert.assertEquals(new Date(1500, 02, 18), new Date(1500, 02, 17).nextDate());
		Assert.assertEquals(new Date(1700, 06, 30), new Date(1700, 06, 29).nextDate());
		Assert.assertEquals(new Date(1800, 11, 30), new Date(1800, 11, 29).nextDate());
		Assert.assertEquals(new Date(3453, 01, 30), new Date(3453, 01, 29).nextDate());
		Assert.assertEquals(new Date(444, 03, 01), new Date(444, 02, 29).nextDate());
		Assert.assertEquals(new Date(2005, 05, 01), new Date(2005, 04, 30).nextDate());
		Assert.assertEquals(new Date(3453, 01, 31), new Date(3453, 01, 30).nextDate());
		Assert.assertEquals(new Date(3456, 03, 31), new Date(3456, 03, 30).nextDate());
		Assert.assertEquals(new Date(1901, 8, 01), new Date(1901, 07, 31).nextDate());
		Assert.assertEquals(new Date(3453, 02, 01), new Date(3453, 01, 31).nextDate());
		Assert.assertEquals(new Date(3457, 01, 01), new Date(3456, 12, 31).nextDate());
		
		
	}

}
