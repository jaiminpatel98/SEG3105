package dateP;

import static org.junit.Assert.*;

import java.util.LinkedList;
import java.util.List;

import org.junit.Assert;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;
import org.junit.Test;

@RunWith(Parameterized.class)
public class ParameterizedDateTestExceptions {

	private int year;
	
	private int month;
	
	private int day;
	
	public ParameterizedDateTestExceptions(int testYear, int testMonth, int testDay) {
		this.year = testYear;
		this.month = testMonth;
		this.day = testDay;
	}
	
	@Parameters
	public static List<Integer[]> data( )
	{
		List<Integer[]> params = new LinkedList<Integer[]>( );
		
		params.add(new Integer[] {1500, 02, 31});
		params.add(new Integer[] {1500, 02, 29});
		params.add(new Integer[] {-1, 10, 20});
		params.add(new Integer[] {1458, 15, 12});
		params.add(new Integer[] {1975, 6, -50});
		return params;
	}
	
	@Test
	public void TestExceptions( )
	{
		try {
			Date testDate = new Date(year, month, day);
			fail("No exceptions occurred");
		} catch(IllegalArgumentException e) {
			
		}
	}

}
